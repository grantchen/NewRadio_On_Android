/** Automatically generated file. DO NOT MODIFY */
package cn.zj.one.hanhan;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}